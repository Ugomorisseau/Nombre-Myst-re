﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace NBWPF
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		// On déclare des variables pour tout le code qui suit (int pour des valeurs numériques).
		private int nbessais;
		private int randomed;
		private int start = 0;
		private DispatcherTimer dt = new DispatcherTimer();

		public MainWindow()
		{
			InitializeComponent();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			// On appelle la méthode Timer et la méthode NouvellePartie.
			Timer();
			NouvellePartie();
		}

		private void dtTicker(object sender, EventArgs e) 
			// On met des conditions en rapport avec le minuteur (à l'aide de if et else). 
			// Par exemple ici : si la variable start dépasse 59 secondes alors le bouton valider se désactive, le minuteur se stop..
		{
			start++;

			TimerLabel.Content = start.ToString();

			if (start > 59)
			{
				this.btnValider.IsEnabled = false;
				dt.Stop();
				textBlockInfo.Text = "Temps écoulé. C'est perdu!";
				textblockperdu.Text = "C'était le nombre: " + randomed;
			}
			else
			{
				textblockperdu.Text = "";
			}
		}

		// Le bouton valider est définit ci-dessous et est associé au "click".
		private void btnValider_Click(object sender, RoutedEventArgs e)
		{
			int saisieNum = PickANumber(); // On déclare la variable saisieNum et on l'associe a la méthode PickANumber.
			// On met des conditions à cette variables (if et else).
			if (saisieNum > 0)
			{
				if (saisieNum != randomed) // : si saisieNum est différent de randomed.
				{
					saisieNum = TryAgain(saisieNum); // On appelle la méthode TryAgain.
					textBoxEssai.Text = "";
				}
				else
				{
					textBoxEssai.Text = "" + randomed;
					YouWin(); // On appelle la méthode YouWin
				}
			}
		}

		// Ici on définit le bouton NouvellePartie de la même manière que le bouton Valider.
		private void btnNouvellePartie_Click(object sender, RoutedEventArgs e)
		{
			// On appelle la méthode NouvellePartie et on active le bouton Valider.
			NouvellePartie();
			this.btnValider.IsEnabled = true;
		}

		// On définit la méthode NouvellePartie.
		private void NouvellePartie()
		{
			randomed = GenereNombreAleatoire(); // la variable randomed est associée ici à la méthode GenereNombreAleatoire
			textBlockInfo.Text = "";
			textBoxEssai.Text = "";
			nbessais = 0; // On remet le nombre d'essais à 0.
			MAJessais(); // On appelle la méthode MAJessais
			start = 0; // On remet le minuteur à 0.
			dt.Start(); // On lance le minuteur.
		}

		// On définit la méthode MAJessais.
		private void MAJessais()
		{
			textBlockNBessais.Text = "Nb d'essais: " + nbessais;

			if (nbessais > 4)
			{
				this.btnValider.IsEnabled = false;

				textBlockInfo.Text = "Tu as utilisé tes 5 essais. C'est perdu!";
				textblockperdu.Text = "C'était le nombre: " + randomed;

				dt.Stop(); // On stop le minuteur.
			}
			else
			{
				textblockperdu.Text = "";
			}
		}

		// On définit la méthode YouWin.
		private void YouWin()
		{
			textBlockInfo.Text = "Bravo! C'est gagné!";
			this.btnValider.IsEnabled = false;
			dt.Stop();
		}

		// On définit la méthode GenereNombreAleatoire.
		private int GenereNombreAleatoire()
		// On génère un nombre aléatoire situé entre 1 et 100.
		{
			return new Random().Next(100) + 1;
		}

		// On définit la méthode TryAgain
		private int TryAgain(int saisieNum)
		{
			// On utilise if et else pour mettre des conditions (ici : si saisiNum est supérieur à randomed alors on affiche "C'est moins!" ...).
			if (saisieNum > randomed)
			{
				textBlockInfo.Text = "C'est moins!";
			}
			else
			{
				textBlockInfo.Text = "C'est plus!";
			}

			nbessais = nbessais + 1;
			MAJessais(); // On appelle la méthode MAJessais.

			return saisieNum; // On retourne la variable saisieNum.
		}

		// On définit la méthode PickANumber.
		private int PickANumber()
		{
			// On définit une variable avec string pour indiquer que c'est une chaine de caractère.
			string saisie = textBoxEssai.Text;

			int saisieNum;

			// On utilise TryParse pour convertir une chaine de caractère en valeur entière et pour vérifier que la conversion est possible.
			bool nombre = int.TryParse(saisie, out saisieNum);
			if (nombre == false)
			{
				textBlockInfo.Text = "Oula, ce n'est pas un nombre. Recommence!";
				textBoxEssai.Text = "";
			}
			else
			{
				textBlockInfo.Text = "";
			}

			return saisieNum;
		}

		//On définit la méthode Timer. C'est le code du minuteur.
		private void Timer()
		{
			dt.Interval = TimeSpan.FromSeconds(1); // On définit un intervalle de temps de une seconde.
			dt.Tick += dtTicker; // On appelle la méthode dtTicker.
			dt.Start(); // On lance le minuteur.
		}
	}
}